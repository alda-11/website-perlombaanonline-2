<?php

$mahasiswa="Alfa";

$nilai=10;

echo $mahasiswa;

print $nilai;


?>