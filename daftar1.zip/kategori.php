<!-- KATEGORI -->
<div class="container-fluid pt-5 pb-5 bg-light">
<div class="container text-center">
	<h2 class="display-3" id="KATEGORI">KATEGORI</h2>
	<h3 class="display-6 id="lomba yang terselengara">lomba yang terselengara</h3>
	<div class="row pt-4 gx-4 gy-4">
	<div class="col-md-4 text-center KATEGORI">
	<img 
	src="https://img.freepik.com/premium-photo/glad-young-asian-men-smiling-looking-laptop-screen-while-working-dressmaking-project-studio-together_102814-3117.jpg?w=1060" class="rounded-circle mb-3 "
	/>
	<h4>LOMBA DESAIN</h4>
	</div>

	<div class="col-md-4 text-center KATEGORI">
	<img 
	src="images/fotoawal.jpg"
	class="rounded-circle mb-3 "
	/>
	<h4>LOMBA PUISI</h4>
	</div>

	<div class="col-md-4 text-center KATEGORI">
	<img 
	src="https://img.freepik.com/premium-vector/international-literacy-day-with-colorful-man-writing-illustration-white-background_86693-477.jpg?w=1380"
	class="rounded-circle mb-3 "
	/>
	<h4>LOMBA MENULIS</h4>
	</div>

	<div class="col-md-4 text-center KATEGORI">
	<img 
	src="https://img.freepik.com/free-vector/flat-background-world-photography-day-celebration_23-2149509290.jpg?t=st=1719153723~exp=1719157323~hmac=1b235e748c1d9a8294875f831d8d74a9139291e4d74d3181a782048648f73e92&w=900"
	class="rounded-circle mb-3 "
	/>
	<h4>LOMBA FOTOGRAFI</h4>
	</div>

	<div class="col-md-4 text-center KATEGORI">
	<img 
	src="https://img.freepik.com/free-photo/different-movie-elements_23-2147775715.jpg?t=st=1719153841~exp=1719157441~hmac=43ddfe77f796a4ea8c51f90f3ee523f5138cbee608917945f874850083939acc&w=900"
	class="rounded-circle mb-3 "
	/>
	<h4>LOMBA VIDIO</h4>
	</div>

	</div>
	</div>
</div>