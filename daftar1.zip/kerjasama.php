<!-- KERJASAMA -->
<div class="container-fluid pt-5 pb-5 ">
<div class="container">
<h2 class="display-3 text-center" id ="KERJASAMA">KERJASAMA</h2>
<p class="text-center">
<b>The University of Strathclyde International Study Centre offers specialist tuition in English language, study skills and subject preparation</b>. Alongside other international students, you'll study programmes developed in collaboration with the University of Strathclyde in preparation for your university degree. 95% of students who completed their pathway programme at the International Study Centre were offered progression to a degree course at the University of Strathclyde in 2023
</p>
<div class="clearfix pt-5">
<img src="https://assets-us-01.kc-usercontent.com/95d47d95-36b6-00af-a24c-b886ecdfc4a2/c09e16d3-5a47-41d6-addf-bebfe59635ed/strathclyde_logo.svg?w=1920&q=75&lossless=true&auto=format"
class="col-md-6 flot-md-end mb-3 crop-img"
width="400" 
height="400">
<p>
	<br>Adapun paket yang kami tawarkan diantaranya:</br>
	<b>Paket Gratis</b>
- 1x posting di feed
- 1x posting di story
- Waktu posting ditentukan admin
- Posting di Blog (opsional)
- Posting di Telegram (opsional)
- Syarat:
     1. Follow Instagram @kabarlomba_com (minimal 1 akun)
     2. Like minimal 12 postingan terbaru @kabarlomba_com Fee: Gratis</p>


<p><b>Paket 1</b>
- 3x posting di feed
- 3x posting di story
- Bebas tentuin tanggal dan jam posting
- Posting di Blog
- Posting di Telegram
Fee: 30k</p>

<p><b>Paket 2</b>
- 5x posting di feed
- 5x posting di story
- Bebas tentuin tanggal dan jam posting
- Posting di Blog
- Posting di Telegram
Fee: 50k</p>

<p><b>paket 5</b>
- 5x posting di feed
- 5x posting di story
- Salah satu post akan disematkan dalam waktu 1 bulan (3 slot only)
- Bebas tentuin tanggal dan jam posting
- Posting di Blog
- Posting di Telegram
Fee: 100k</p>
</div>
</div>
</div>