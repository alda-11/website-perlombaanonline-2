 <!--TINGKAT -->
       /li>
            <li class="dropdown">
            <a href="#TINGKATAN" class="nav-link" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="nav-item "></span> TINGKATAN <span class="caret"></span>
            </a>
              <ul class="dropdown-menu">
                <li><a href="#">Teknik Informatika</a></li>
                <li><a href="#">Manajemen Informatika</a></li>
                <li><a href="#">Teknik Elektro</a></li>
                <li><a href="#">Akuntansi</a></li>
              </ul>
            </li>
        </li>
     
    </div>