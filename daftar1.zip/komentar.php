<?php
/*
    Ini adalah file untuk memberikan contoh
    komentar pada PHP
    Ini contoh komentar beberapa baris
*/

//Contoh variabel $jumlah_mahasiswa bernilai 10
$jumlah_mahasiswa=10;

//ini untuk menampilkan nilai variable $jumlah_mahasiswa
echo $jumlah_mahasiswa;


?>