<?php

$koneksi= new mysqli("localhost","root","","submite_lomba");

//$koneksi= new mysqli("HOST_ATAU_IP_SERVE","USERNAME_AKSES_MYSQL","PASSWORD_MYSQL","NAMA_DATABASE");

?>