<?php

$nilai_a=10;

$nilai_b=4;

$jumlah= $nilai_a + $nilai_b;//penjumlahan

$kali= $nilai_a * $nilai_b;//perkalian

$bagi= $nilai_a / $nilai_b;//pembagian

$kurang= $nilai_a - $nilai_b;//pengurangan

$mod= $nilai_a % $nilai_b;//sisa bagi/modulo

echo "Nilai A= ".$nilai_a."<br>";
echo "Nilai B= ".$nilai_b."<br>";

echo "Nilai A + Nilai B= ".$jumlah."<br>";
echo "Nilai A * Nilai B= ".$kali."<br>";
echo "Nilai A / Nilai B= ".$bagi."<br>";
echo "Nilai A - Nilai B= ".$kurang."<br>";
echo "Nilai A % Nilai B= ".$mod."<br>";


?>